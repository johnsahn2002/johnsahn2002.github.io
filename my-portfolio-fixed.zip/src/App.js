import React from 'react';
import Portfolio from './Pages/Portfolio';

function App() {
  return <Portfolio />;
}

export default App;
